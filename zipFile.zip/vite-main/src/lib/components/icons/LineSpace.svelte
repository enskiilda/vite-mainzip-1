<script lang="ts">
	export let className = 'size-4';
	export let strokeWidth = '1.5';
</script>

<svg
	xmlns="http://www.w3.org/2000/svg"
	fill="none"
	viewBox="0 0 24 24"
	stroke-width={strokeWidth}
	stroke="currentColor"
	class={className}
	><path d="M11 6H21" stroke-linecap="round" stroke-linejoin="round"></path><path
		d="M11 12H21"
		stroke-linecap="round"
		stroke-linejoin="round"
	></path><path d="M11 18H21" stroke-linecap="round" stroke-linejoin="round"></path><path
		d="M5 19V5M5 19L3 16.5M5 19L7 16.5M5 5L3 7M5 5L7 7"
		stroke-linecap="round"
		stroke-linejoin="round"
	></path></svg
>
