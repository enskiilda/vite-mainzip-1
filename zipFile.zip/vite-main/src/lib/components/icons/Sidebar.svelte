<script lang="ts">
	export let className = 'size-5';
	export let strokeWidth = '1.5';
</script>

<svg
	xmlns="http://www.w3.org/2000/svg"
	fill="none"
	viewBox="0 0 24 24"
	stroke-width={strokeWidth}
	stroke="currentColor"
	class={className}
	><rect
		x="3"
		y="3"
		width="18"
		height="18"
		rx="5"
		ry="5"
		stroke="currentColor"
		stroke-linecap="round"
		stroke-linejoin="round"
		fill="none"
	></rect><path d="M9.5 21V3" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
	></path></svg
>
