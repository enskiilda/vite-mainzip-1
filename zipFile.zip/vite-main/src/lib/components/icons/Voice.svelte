<script lang="ts">
	export let className = 'w-4 h-4';
	export let strokeWidth = '1.5';
</script>

<svg
	aria-hidden="true"
	xmlns="http://www.w3.org/2000/svg"
	fill="currentColor"
	viewBox="0 0 24 24"
	stroke-width={strokeWidth}
	stroke="currentColor"
	class={className}
	><path d="M12 4L12 20" stroke-linecap="round" stroke-linejoin="round"></path><path
		d="M8 9L8 15"
		stroke-linecap="round"
		stroke-linejoin="round"
	></path><path d="M20 10L20 14" stroke-linecap="round" stroke-linejoin="round"></path><path
		d="M4 10L4 14"
		stroke-linecap="round"
		stroke-linejoin="round"
	></path><path d="M16 7L16 17" stroke-linecap="round" stroke-linejoin="round"></path></svg
>
