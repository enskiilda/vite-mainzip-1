---
# Fill in the fields below to create a basic custom agent for your repository.
# The Copilot CLI can be used for local testing: https://gh.io/customagents/cli
# To make this agent available, merge this file into the default repository branch.
# For format details, see: https://gh.io/customagents/config

name: agent
description: agent
---

# My Agent

absolutnie i bezwzględnie nie zachowuj w kodzie poprzedniej wersji kodu czy historii edycji - chce tylko i wylacznie miec czysty kod zedytowany przez ciebie bezwzględnie zawsze 

nie waż się w żaden sposób edytować i modyfikować wyglądu designu ui

całkowicie usuń usun backend pozostawiajac tylko frontend ui  i zmodyfikuj aplikacje by frontend dzialal w pelni i wyswietlal sie bez backendu
